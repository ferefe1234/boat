# Validation status

Completed on this workspace:

- **Android debug build succeeded on 2026-10-30:** the user ran
  `gradle :app:assembleDebug :app:lintDebug` successfully. The resulting APK
  was confirmed at `android/app/build/outputs/apk/debug/app-debug.apk`
  (6,727,461 bytes), version 1.0.0, package `app.qrtransfer.android`, minimum
  SDK 24. The generated lint report records **0 errors and 8 warnings**.
  Back navigation uses AndroidX's dispatcher, the SDK property is escaped,
  and Kotlin runtime dependencies are aligned through the 1.8.22 BOM.
  Verification of this build result uses the user's terminal output and the
  resulting local artifacts; the agent's own Gradle runs remained restricted.
- **137 tests passed** across 16 test files: fountain reconstruction, wire-format
  and file integrity checks, transfer round trips, QR raster layouts, worker pool,
  progress, localization, PNG/APNG/ZIP, snippets, format/display, no-signal hints,
  subscription boundaries and advertisement cadence.
- Browser-side TypeScript: **0 diagnostics** with the installed TypeScript 6.0.3,
  the published qrcode type declarations, and temporary ambient declarations for
  Vite-specific imports. This is not a substitute for the locked npm build.
- Git blob hashes confirm the imported protocol, fountain, QR raster, worker
  pool, QR generator, decode worker and vendored JS/WASM codec are byte-identical
  to upstream commit `5301fc2020716b5a97d4edf6e1793c3dedbf6e17`.

The initial 137-test run used an existing Node 20.18 executable and the local
TypeScript transpiler while dependency installation was unavailable to the agent.
The animation-export test file required the then-unavailable qrcode runtime
dependency and was excluded. The CI build runs the complete `npm test` suite
on Node 24; no later full-suite result has been recorded here.

The web assets, logo JPEG and generated launcher resources are now present and
the APK build completed. Physical-device camera/transfer tests, performance
benchmarks, visual inspection on a device and Play subscription tests remain
outstanding. No measured scanning speed improvement is claimed.

The local network refused GitHub archive and image downloads. Source was
retrieved through the GitHub connector; two optional large demo images exceeded
that connector's size limit. Their restoration script uses the pinned commit.
